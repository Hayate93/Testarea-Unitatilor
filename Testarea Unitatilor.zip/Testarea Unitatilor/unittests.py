import math
import unittest


def division(a, b):
    return a / b



class DivisionTestSuite(unittest.TestCase):
    def test_divide_by_0(self):
        """
        If the second argument for the division() function is zero, the program should
          raise a ZeroDivisionError exception
        """

        self.assertRaises(ZeroDivisionError, division, 10, 0)

    def test_str_arguments(self):
        """
        The division() function should typecheck for the str type, and return "You Passed a 'str' argument for division".
        """

        a, b = 2, '3'
        self.assertRaises(TypeError, division, a, b)

        a, b = '2', 3
        self.assertRaises(TypeError, division, a, b)

        a, b = '2', '3'
        self.assertRaises(TypeError, division, a, b)


if __name__ == '__main__':
    unittest.main()
